﻿<# PID = Product Key for SQL Server Installation
For volumen license contract, the Product key is embedded in the media
without PID in parameters, the edition based on media (embedded license) is installed.
Well know PIDs are:
Developer Edition
PID = "22222-00000-00000-00000-00000"
Express Edition 
PID = "11111-00000-00000-00000-00000"

If you have a Product Key, use Parameter
Edition = "Standard" or "Enterprise"
and your 
ProductKEy = "XXXXX-XXXXX-XXXXX-XXXXX-XXXXX"
#>
$SqlServer="<SERVERNAME>"
$config = @{
    UPDATEENABLED = "False"
    SUPPRESSPAIDEDITIONNOTICE = "True"
    IACCEPTPYTHONLICENSETERMS = "True"
    IACCEPTROPENLICENSETERMS = "True"
    IACCEPTSQLSERVERLICENSETERMS = "True"
    QUIET = "True"
    SAPWD="VerySecretPassword!!"
    SQLMAXDOP="2"
    PID = "22222-00000-00000-00000-00000"
    INSTALLSQLDATADIR="D:"
}

$installparams = @{
    SqlInstance     = $SqlServer
    AuthenticationMode = "Mixed"
    Version         = 2022
    Verbose         = $true
    Confirm         = $false
    Credential      = $cred
    Feature         = "Engine"
    PerformVolumeMaintenanceTasks = $true
    AdminAccount    = "contoso.com\MyadminAccount"
    InstancePath    = "C:\Program Files\Microsoft SQL Server"
    DataPath        = "F:\MSSQL16.MSSQLSERVER\MSSQL\DATA"
    TempPath        = "H:\MSSQL16.MSSQLSERVER\MSSQL\TEMP"
    LogPath         = "G:\MSSQL16.MSSQLSERVER\MSSQL\LOG"
    Path            = "\\networkshare\sql\2022"
    Configuration   = $config
}

Install-DbaInstance @installparams 






