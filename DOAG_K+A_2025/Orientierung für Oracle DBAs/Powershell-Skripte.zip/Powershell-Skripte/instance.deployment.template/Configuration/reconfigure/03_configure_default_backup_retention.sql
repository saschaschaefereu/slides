EXEC sys.sp_configure N'media retention', N'14'
GO
RECONFIGURE WITH OVERRIDE
GO
