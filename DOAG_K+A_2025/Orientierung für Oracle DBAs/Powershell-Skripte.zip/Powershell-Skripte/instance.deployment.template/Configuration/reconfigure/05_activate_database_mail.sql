USE msdb
GO
sp_configure 'show advanced options', 1;  
GO
RECONFIGURE;
GO
sp_configure 'Database Mail XPs', 1;
GO
RECONFIGURE
GO