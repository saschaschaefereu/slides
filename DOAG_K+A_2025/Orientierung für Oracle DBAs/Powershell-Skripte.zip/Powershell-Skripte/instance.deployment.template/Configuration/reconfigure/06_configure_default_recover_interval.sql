USE master
GO
sp_configure 'show advanced option', 1;  
GO
RECONFIGURE WITH OVERRIDE;
GO
sp_configure 'recovery interval (min)', 60;  
GO
RECONFIGURE WITH OVERRIDE;
GO
