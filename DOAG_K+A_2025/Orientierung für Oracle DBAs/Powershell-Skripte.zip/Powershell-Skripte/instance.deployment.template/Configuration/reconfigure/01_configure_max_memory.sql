sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
sp_configure 'max server memory', 16000;
GO
RECONFIGURE;
GO