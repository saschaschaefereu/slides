﻿param (
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$sqlServer,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$database
     )

function deploy ([String]$sqlServer, [String]$database,[String]$myWd){
    New-DbaFirewallRule -SqlInstance $sqlServer -Confirm:$false
    # set default path for data and log if not already set on installation
    Set-DbaDefaultPath -SqlInstance $sqlServer -Type Data -Path "F:\MSSQL16.MSSQLSERVER\MSSQL\DATA"
    Set-DbaDefaultPath -SqlInstance $sqlServer -Type Log  -Path "G:\MSSQL16.MSSQLSERVER\MSSQL\LOG"

    Set-DbaSpConfigure -SqlInstance $sqlServer -Name "backup compression default" -Value 1
    Set-DbaSpConfigure -SqlInstance $sqlServer -Name "backup checksum default" -Value 1
    
    Install-DbaMaintenanceSolution  -SqlInstance $sqlServer -BackupLocation "\\backupserver\sqlserver"   -AutoScheduleJobs "DailyFull" -CleanupTime 340 -InstallJobs -LogToTable  -StartTime "170000"
    Install-DbaFirstResponderKit    -SqlInstance $sqlServer -Database $database -Force
    Install-DbaWhoIsActive          -SqlInstance $sqlServer -Database $database -Force
	Install-DbaDarlingData          -SqlInstance $sqlServer -Database $database -Force
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\01_configure_max_memory.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\02_configure_login_auditing.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\03_configure_default_backup_retention.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\04_configure_size_serverlogs.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\05_activate_database_mail.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\06_configure_default_recover_interval.sql"

    $profileName="db_mail_"+$sqlServer.ToLower()
    New-DbaDbMailAccount -SqlInstance $sqlServer -Account "DBA" -Description "DBA Mailaccount" -MailServer "mail.contoso.com" -EmailAddress "mailtodba@contoso.com" -Verbose -force 
    New-DbaDbMailProfile -SqlInstance $sqlServer -Profile $profileName -Description "Profile für Datenbankemail" -MailAccountName "DBA"  -Verbose

    New-DbaAgentOperator    -SqlInstance $sqlServer -Operator "DBA" -EmailAddress "mailtodba@contoso.com"  -PagerDay Everyday -Force
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseIntegrityCheck - SYSTEM_DATABASES" -EmailLevel "Always" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseIntegrityCheck - USER_DATABASES"   -EmailLevel "Always" -EmailOperator "DBA"

    # assume, english os installation
    Set-DbaPowerPlan -ComputerName $sqlServer -PowerPlan 'High Performance'
    
    $securePassword=Get-SecurePassword "sa_<servername>"
    if ( $null -ne $securePassword){
        Set-DbaLogin -SqlInstance $sqlServer -Login sa -SecurePassword $securePassword 
    }  
}

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
deploy $sqlServer $database $myWd
