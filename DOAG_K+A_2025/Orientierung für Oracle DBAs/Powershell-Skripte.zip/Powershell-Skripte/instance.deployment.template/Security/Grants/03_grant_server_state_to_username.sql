USE [MASTER]
GO
-- grant select on dynamic management views and functions for monitoring
GRANT VIEW SERVER STATE TO <username>
GO