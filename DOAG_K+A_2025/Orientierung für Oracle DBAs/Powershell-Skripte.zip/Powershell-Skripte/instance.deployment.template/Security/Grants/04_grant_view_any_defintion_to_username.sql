USE [MASTER]
GO
-- select any ddl of objects like tables, triggers, function but no data in this objects
GRANT VIEW ANY DEFINITION TO <username>
GO