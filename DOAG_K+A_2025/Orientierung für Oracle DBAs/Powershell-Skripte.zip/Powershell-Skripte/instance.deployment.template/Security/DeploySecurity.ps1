param (
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$sqlServer,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$database
     )

function deploy ([String]$sqlServer, [String]$database, [String]$myWd){
    New-DbaFirewallRule -SqlInstance $sqlServer -Confirm:$false
    Set-DbaSpConfigure -SqlInstance $sqlServer -Name "backup compression default" -Value 1
    Set-DbaSpConfigure -SqlInstance $sqlServer -Name "backup checksum default" -Value 1
    New-DbaLogin -SqlInstance $sqlServer -Login "contoso.com\MyadminAccount" -DefaultDatabase $database       
    Add-DbaServerRoleMember -SqlInstance $sqlServer -ServerRole sysadmin -Login "contoso.com\MyadminAccount"    -Confirm:$false
    # the get-SecurePassword function is not included in the examples
    # it is used to get the secure password from a vault like
    # powershell password vault or hashicorp vault
    # please implement this function on your own
    $securePassword=get-SecurePassword "<username>"
    if ( $null -ne $securePassword){    
        New-DbaLogin  -SqlInstance $sqlServer  -login "<username>" -SecurePassword $securePassword
        New-DbaDbUser -SqlInstance $sqlServer -Database $database -Login "<username>" -Username "<username>" -Confirm:$false
        Remove-DbaServerRoleMember -SqlInstance $sqlServer -ServerRole serveradmin -Login "<username>"    -Confirm:$false
        if (Test-Path -path "$myWd\Grants\03_grant_server_state_to_<username>.sql"){
            Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\03_grant_server_state_to_<username>.sql"
        }
        if (Test-Path -path "$myWd\Grants\04_grant_view_any_defintion_to_<username>.sql"){
            Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\04_grant_view_any_defintion_to_<username>.sql"
        }            
    }    
    
    Install-DbaFirstResponderKit -SqlInstance $sqlServer  -Force
    Install-DbaMaintenanceSolution -SqlInstance $sqlServer -BackupLocation "\\backupserver\sqlserver"   -AutoScheduleJobs "DailyFull" -CleanupTime 340 -InstallJobs -LogToTable  -StartTime "170000"
    Install-DbaWhoIsActive -SqlInstance $sqlServer -Database "Master" -force
	Install-DbaDarlingData -SqlInstance $sqlServer -Database "Master"  -force
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\01_configure_max_memory.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\02_configure_login_auditing.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\03_configure_default_backup_retention.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\04_configure_size_serverlogs.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\05_activate_database_mail.sql"
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\reconfigure\06_configure_default_recover_interval.sql"

    $profileName="db_mail_"+$sqlServer.ToLower()
    New-DbaDbMailAccount -SqlInstance $sqlServer -Account "DBA" -Description "DBA Mailaccount" -MailServer "mail.contoso.com" -EmailAddress "mailtodba@contoso.com" -Verbose -force 
    New-DbaDbMailProfile -SqlInstance $sqlServer -Profile $profileName -Description "Profile für Datenbankemail" -MailAccountName "DBA"  -Verbose

    New-DbaAgentOperator    -SqlInstance $sqlServer -Operator "DBA" -EmailAddress "mailtodba@contoso.com"  -PagerDay Everyday -Force
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseIntegrityCheck - SYSTEM_DATABASES" -EmailLevel "Always" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseIntegrityCheck - USER_DATABASES"   -EmailLevel "Always" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseBackup - SYSTEM_DATABASES - FULL" -EmailLevel "OnFailure" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseBackup - USER_DATABASES - DIFF" -EmailLevel "OnFailure" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseBackup - USER_DATABASES - FULL" -EmailLevel "OnFailure" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "DatabaseBackup - USER_DATABASES - LOG" -EmailLevel "OnFailure" -EmailOperator "DBA"
    Set-DbaAgentJob -SqlInstance  $sqlServer -Job "IndexOptimize - USER_DATABASES" -EmailLevel "OnFailure" -EmailOperator "DBA"
    
    # set sa_password based on password of vault
    $securePassword=Get-SecurePassword "<sa_username>"
    if ( $null -ne $securePassword){
        Set-DbaLogin -SqlInstance $sqlServer -Login "<sa_username>" -SecurePassword $securePassword 
    }         
}
Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
switch ($environment) {
    "<ENV>" {
        loginfo "Deploy security on environment(${environment}), serverinstance($sqlServer) database: $database wd: $myWD" ($MyInvocation.MyCommand.Name)
        deploy $sqlServer $database $myWd
    }
    Default {
        Write-Error "Invalid environment specified. Please provide one of the following: DEV "
        exit 1
    }
}