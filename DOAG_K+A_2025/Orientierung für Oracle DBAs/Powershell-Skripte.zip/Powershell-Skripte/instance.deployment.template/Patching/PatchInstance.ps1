﻿<# Update local buildreference file, check installation $sqlServer against this file. Download patches and install
#>
$SqlServer="<SERVERNAME>"
$patchStorage="\\filesserver\patches"

# update local builreference to the latest release from dbatools.io, a JSON-based reference of all the available patches
# https://dbatools.io/buildref/
Get-DbaBuildReference -update

# get the current installed patches
# Get-DbaInstalledPatch $SqlServer

# check server is on the latest update based on local buildreference
Test-DbaBuild -sqlInstance $SqlServer -Latest

# check server is on the latest update based on buildreference, before check, 
# update the buildreference to latest release from dbatools.io
Test-DbaBuild -sqlInstance $SqlServer -Latest -update

# get current patch status of $sqlServer
$preCheck = Test-DbaBuild -sqlInstance $SqlServer -latest

if ($preCheck.Compliant -eq $false){
        $targetVersion = $preCheck.BuildTarget
        $KB = $preCheck.KBLevel
        $patchFolder = Join-path $patchStorage $targetVersion
        Save-DbaKbUpdate -Kb $KB -Path $PatchFolder -architecture x64
        Update-DbaInstance -ComputerName $sqlServer -Version $targetVersion -Restart -Confirm:$false -Verbose
}