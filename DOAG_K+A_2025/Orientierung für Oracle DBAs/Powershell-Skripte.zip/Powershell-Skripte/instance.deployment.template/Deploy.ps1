<#
.SYNOPSIS
Deploys configuration and security settings to a specified SQL Server environment.

.DESCRIPTION
This script is used to deploy configuration and security settings to a SQL Server instance. 
It imports necessary modules, sets up the environment, and executes deployment scripts 
for configuration and security.

.PARAMETER environment
Specifies the target environment for deployment.

.PARAMETER sqlServer
Specifies the target SQL Server instance for deployment.

.NOTES
- The script uses the dbatool modules for database operations.
- The deployment scripts for configuration and security are located in the 
    "Configuration" and "Security" subdirectories relative to the script's location.

.EXAMPLE
.\Deploy.ps1
This will deploy configuration and security settings to the <ENV> environment on the 
default SQL Server instance specified in the script.
#>

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
$environment="<ENV>" # Environment set to DEV, TEST or PROD
$sqlServer="<SERVERNNAME>" # SQL Server set Servername
Write-Output "$environment : Deploy on $sqlServer"
& $myWd\Configuration\DeployConfiguration.ps1 $environment $sqlServer "Master"
& $myWd\Security\DeploySecurity.ps1 $environment $sqlServer "Master"