param (
            [Parameter(Mandatory=$true)][ValidateSet("PROD","TEST","DEV")][string]$environment,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$sqlServer,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$database
     )
function deploy ([String]$sqlServer,[String]$database,[String]$myWd,[String]$environment){
    New-DbaDatabase -SqlInstance $sqlServer -name $database -RecoveryModel Full -Owner sa -PrimaryFilesize 256 -PrimaryFileGrowth 256
                    -PrimaryFileMaxSize 20480 -LogSize 128 -LogGrowth 128 -LogMaxSize 20480 
}

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
deploy $sqlServer $database $myWd $environment
