param (
            [Parameter(Mandatory=$true)][ValidateSet("PROD","TEST","DEV")][string]$environment,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$sqlServer,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$database
     )
function deploy (){
    Set-DbaDbQueryStoreOption -SqlInstance $sqlServer -Database $database -State ReadWrite
}

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
deploy $sqlServer $database $myWd