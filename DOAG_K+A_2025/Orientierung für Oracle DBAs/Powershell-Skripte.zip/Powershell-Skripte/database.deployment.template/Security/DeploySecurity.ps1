﻿<#
.SYNOPSIS
Deploys database users and roles to a specified SQL Server instance and database.

.DESCRIPTION
This script deploys database users and roles to a specified SQL Server instance and database. 
It uses the dbatools module to create logins, database users, and roles, and assigns the appropriate permissions.

.PARAMETER environment
Specifies the environment in which to deploy the users and roles. Valid values are "PROD", "TEST", and "DEV".

.PARAMETER sqlServer
Specifies the SQL Server instance where the users and roles will be deployed.

.PARAMETER database
Specifies the database where the users and roles will be deployed.

.FUNCTION Get-SecurePassword
Retrieves a secure password from the Microsoft.PowerShell.SecretStore module.

.PARAMETER userName
The username for which to retrieve the secure password.

.FUNCTION deploy
Deploys database users and roles to the specified SQL Server instance and database.

.PARAMETER sqlServer
The SQL Server instance where the users and roles will be deployed.

.PARAMETER database
The database where the users and roles will be deployed.

.PARAMETER myWd
The working directory path where the script is located.

.EXAMPLE
.\DeploySecurity.ps1 -environment "PROD" -sqlServer "mySqlServer" -database "myDatabase"
Deploys the users and roles to the "myDatabase" database on the "mySqlServer" instance in the "PROD" environment.

.NOTES
Requires the dbatools module and Microsoft.PowerShell.SecretStore module.
#>


param (
            [Parameter(Mandatory=$true)][ValidateSet("PROD","TEST","DEV")][string]$environment,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$sqlServer,
            [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$database
     )

# Function to deploy database users and roles
# Parameters:
#   [String]$sqlServer - The SQL Server instance
#   [String]$database - The database name
#   [String]$myWd - The working directory path
function deploy ([String]$sqlServer,[String]$database,[String]$myWd){
    $areaName="<AREANAME>"

    $securePassword=get-SecurePassword "<username>"
    if ( $null -ne $securePassword){    
        New-DbaLogin  -SqlInstance $sqlServer -login "<username>" -SecurePassword $securePassword -Language German
        New-DbaDbUser -SqlInstance $sqlServer -Database $database -Login "<username>" -Username "<username>" -Confirm:$false
        if (Test-Path -path "$myWd\Grants\03_grant_server_state_to_<username>.sql"){
            Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\03_grant_server_state_to_<username>.sql"
        }
         if (Test-Path -path "$myWd\Grants\02_change_<username>_language.sql"){
          Invoke-Sqlcmd -ServerInstance $sqlServer -Database "master" -TrustServerCertificate -InputFile "$myWd\Grants\02_change_<username>_language.sql"
        }            
    }    
    
    $securePassword=get-SecurePassword "<username>"
    if ( $null -ne $securePassword){
        New-DbaLogin  -SqlInstance $sqlServer -DefaultDatabase $database -login "<username>" -SecurePassword $securePassword 
        New-DbaDbUser -SqlInstance $sqlServer -Database $database -Login "<username>" -Username "<username>"  -Confirm:$false -force
        if (Test-Path -path "$myWd\Grants\01_grant_to_user_<username>.sql"){
          Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\01_grant_to_user_<username>.sql"
        }       
    }

    $securePassword=get-SecurePassword "<sqlusername>"
    if ( $null -ne $securePassword){
        New-DbaLogin  -SqlInstance $sqlServer -DefaultDatabase $database -login "<sqlusername>" -SecurePassword $securePassword 
        New-DbaDbUser -SqlInstance $sqlServer -Database $database -Login "<sqlusername>" -Username "<sqlusername>"  -Confirm:$false
        Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datareader" -Member "<sqlusername>" -Confirm:$false
        Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datawriter" -Member "<sqlusername>" -Confirm:$false
    }  
        
    New-DBaLogin -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_DDL_$areaName" -DefaultDatabase $database -Force
    New-DBaLogin -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RO_$areaName"  -DefaultDatabase $database -Force
    New-DBaLogin -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RW_$areaName"  -DefaultDatabase $database -Force 
    New-DBaLogin -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RL_SHOW_QUERYSTORE_$areaName"  -DefaultDatabase $database -Force 
    New-DBaLogin -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RL_DEVELOPER_$areaName"  -DefaultDatabase $database -Force 

    New-DbaDbUser -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_DDL_$areaName" -Username "contoso.com\PRG_DB_USER_DDL_$areaName" -Database $database -Force
    New-DbaDbUser -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RO_$areaName"  -Username "contoso.com\PRG_DB_USER_RO_$areaName" -Database $database -Force
    New-DbaDbUser -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RW_$areaName"  -Username "contoso.com\PRG_DB_USER_RW_$areaName" -Database $database -Force  
    New-DbaDbUser -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RL_SHOW_QUERYSTORE_$areaName"  -Username "contoso.com\PRG_DB_USER_RL_SHOW_QUERYSTORE_$areaName" -Database $database -Force  
    New-DbaDbUser -SqlInstance $sqlServer -Login "contoso.com\PRG_DB_USER_RL_DEVELOPER_$areaName"  -Username "contoso.com\PRG_DB_USER_RL_DEVELOPER_$areaName" -Database $database -Force  

    New-DbaDbRole  -SqlInstance $sqlServer -Database $database -Role "db_show_querystore_$areaName" 
    New-DbaDbRole  -SqlInstance $sqlServer -Database $database -Role "db_developer_$areaName" 

    #  -Confirm:$false is need due to bug
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datareader"    -Member "contoso.com\PRG_DB_USER_DDL_$areaName"  -Confirm:$false
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datareader"    -Member "contoso.com\PRG_DB_USER_RO_$areaName"   -Confirm:$false
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datareader"    -Member "contoso.com\PRG_DB_USER_RW_$areaName"   -Confirm:$false

    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datawriter"    -Member "contoso.com\PRG_DB_USER_RW_$areaName"  -Confirm:$false
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_datawriter"    -Member "contoso.com\PRG_DB_USER_DDL_$areaName" -Confirm:$false
    
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -role "db_ddladmin"      -Member "contoso.com\PRG_DB_USER_DDL_$areaName" -Confirm:$false 

    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -Role "db_show_querystore_$areaName" -Member "contoso.com\PRG_DB_USER_RL_SHOW_QUERYSTORE_$areaName" -Confirm:$false
    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -Role "db_show_querystore_$areaName" -Member "<sqlusername>" -Confirm:$false

    Add-DbaDbRoleMember -SqlInstance $sqlServer -Database $database -Role "db_developer_$areaName" -Member "contoso.com\PRG_DB_USER_RL_DEVELOPER_$areaName" -Confirm:$false

    if (Test-Path -path "$myWd\Grants\01_grant_to_role_db_show_querystore_$areaName.sql"){
        Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\01_grant_to_role_db_show_querystore_$areaName.sql"
    }
    if (Test-Path -path "$myWd\Grants\03_grant_to_role_db_developer_$areaName.sql"){
        Invoke-Sqlcmd -ServerInstance $sqlServer -Database $database -TrustServerCertificate -InputFile "$myWd\Grants\03_grant_to_role_db_developer_$areaName.sql"
    }    
}

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
deploy $sqlServer $database $myWd

