<#
.SYNOPSIS
Deploys <DATABASENAME> database configuration and security settings to the specified environment.

.DESCRIPTION
This script deploys the <DATABASENAME> database configuration and security settings to the specified environment (PROD, TEST, or DEV). 
It imports necessary modules, sets up an insecure connection for the session, and executes deployment scripts based on the environment.

.PARAMETER environment
Specifies the environment to deploy to. Valid values are 'PROD', 'TEST', and 'DEV'.

.EXAMPLE
.\Deploy.ps1 -environment PROD
Deploys the configuration and security settings to the production environment.

.EXAMPLE
.\Deploy.ps1 -environment TEST
Deploys the configuration and security settings to the test environment.

.EXAMPLE
.\Deploy.ps1 -environment DEV
Deploys the configuration and security settings to the development environment.

.NOTES
- Requires the dbatool modules.
#>

param (
    [Parameter(Mandatory=$true, HelpMessage="Specifies the environment to deploy to. Valid values are 'PROD', 'TEST', and 'DEV'.")][ValidateSet("PROD","TEST","DEV")][string]$environment
)

Import-Module dbatools
$myWd = Split-Path -path $MyInvocation.MyCommand.Path
$database = "<DATABASENAME>"
switch ($environment) {
    "PROD" {
        $sqlServer="<SERVERNAME, e.g 'sqlprod01'>"
        & $myWd\CreateDatabase\DeployDatabase.ps1 $environment $sqlServer $database
        & $myWd\Configuration\DeployConfiguration.ps1 $environment $sqlServer $database
        & $myWd\Security\DeploySecurity.ps1 $environment $sqlServer $database
    }
    "TEST" {
        $sqlServer="<SERVERNAME>, e.g 'sqltest01'>"
        & $myWd\CreateDatabase\DeployDatabase.ps1 $environment $sqlServer $database
        & $myWd\Configuration\DeployConfiguration.ps1 $environment $sqlServer $database
        & $myWd\Security\DeploySecurity.ps1 $environment $sqlServer $database
    }
    "DEV" {
        $sqlServer="<SERVERNAME>, e.g 'sqldev01'>"
        & $myWd\CreateDatabase\DeployDatabase.ps1 $environment $sqlServer $database
        & $myWd\Configuration\DeployConfiguration.ps1 $environment $sqlServer $database
        & $myWd\Security\DeploySecurity.ps1 $environment $sqlServer $database
    }
    Default {
        Write-Output "A valid environment (PROD, TEST, DEV) is needed"
        exit 1
    }
}
exit 0