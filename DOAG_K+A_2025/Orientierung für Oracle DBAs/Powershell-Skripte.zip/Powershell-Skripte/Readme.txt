Die dbatools müssen vor der ersten Verwendung installiert werden.  (https://dbatools.io/install/). In den Skripten wird nur das Modul importiert. Die Skripte setzen eine Powershell mit administrativen Rechten (elevated) voraus. Der User in dessen Kontext die Session läuft, benötigt auf dem SQL Server administrative Rechte(sysadmin).

Die Skripte können frei verwendet werden. Use at your own risk! Bitte immer auf Testsystem oder Sandboxes testen.


Viel Spaß!
Sascha Schäfer

sascha.schaefer@warema.de
https://www.linkedin.com/in/sascha-schaefer-eu/
https://bsky.app/profile/saschaschaefer.eu